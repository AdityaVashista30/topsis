# -*- coding: utf-8 -*-
"""
Created on Sun Jan 19 23:27:12 2020

@author: Aditya Vashista (101703039,TIET)
"""
from topsis.topsis import topsis
